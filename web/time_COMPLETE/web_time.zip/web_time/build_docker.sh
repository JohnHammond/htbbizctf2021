#!/bin/bash
docker rm -f web_time
docker build -t web_time . && \
docker run --name=web_time --rm -p1337:80 -it web_time